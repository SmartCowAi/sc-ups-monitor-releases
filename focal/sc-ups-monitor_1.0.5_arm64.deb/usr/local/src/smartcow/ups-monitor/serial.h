/*
 * Helper functions for serial communications, intended for use with the
 * PB-4600J UPS
 *
 * Authors: Ryan Agius          <ryan@smartcow.ai>
 *          Stoyan Bogdanov     <stoyanb@smartcow.ai>
 * 
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file COPYING in the main directory of this archive
 * for more details. 
 */

#ifndef SMC_SERIAL_H_
#define SMC_SERIAL_H_

#include <stdint.h> 

#define ERROR_UPS_UNREACHABLE 17

#define SERIAL_BAUD             B115200 // default ups baud rate
#define SERIAL_WRITE_SLEEP_US   3000    // sleep for 3000us after write
#define SERIAL_READ_SLEEP_US    3000    // sleep for 3000us after read

/**
 * serial_open() - opens the controller serial port
 * @serial_path: string path to serial dev
 * 
 * Returns the serial port file descriptor if successful, -ERR if not
 */
int serial_open(const char *serial_path);

/**
 * serial_close() - closes the controller serial port
 * @serial_fd: serial port file descriptor
 * 
 * Returns 0 successful, -ERR if not
 */
int serial_close(int serial_fd);

/**
 * serial_configure() - configure the controller serial port
 * @serial_fd: serial port file descriptor
 * 
 * Returns the serial port file descriptor if successful, -ERR if not
 */
int serial_configure(int serial_fd);

/**
 * serial_write() - writes messages to a serial port
 * @p_msg: pointer to a uint8_t array containing the message
 * @n_msg: size of the message in bytes
 * @serial_fd: serial port file descriptor
 * 
 * Returns the number of bytes sent on success, -ERR on fail
 */
int serial_write(uint8_t *p_msg, int n_msg, int serial_fd);

/**
 * serial_read() - reads message from a serial port
 * @p_msg: pointer to a uint8_t array to receive the message
 * @n_msg: size of the message in bytes
 * @serial_fd: serial port file descriptor
 * 
 * Returns the number of bytes received on success, -ERR on fail
 */
int serial_read(uint8_t *rx_buf, int n_msg, int serial_fd);

#endif