/*
 * Helper functions for serial communications, intended for PB-4600J UPS
 *
 * Authors: Ryan Agius  <ryan@smartcow.ai>
 *
 *
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file COPYING in the main directory of this archive
 * for more details. 
 */

#include <stdio.h>
#include <stdint.h> 
#include <stdlib.h>
#include <termios.h>
#include <string.h>

#include <sys/file.h>
#include <fcntl.h>
#include <errno.h>
#include <termios.h> 
#include <unistd.h>

#include "serial.h"

#define DEBUG 0

static struct termios tty_ups;

int serial_configure(int serial_port)
{
    // populate struct with current serial settings, seeing if they can be read
    if (tcgetattr(serial_port, &tty_ups) < 0) {
        printf("Error %i from tcgetattr: %s\n", errno, strerror(errno));
        return errno;
    }

    // set baud rate to lidar default
    cfsetispeed(&tty_ups, SERIAL_BAUD);
    cfsetospeed(&tty_ups, SERIAL_BAUD);

    // set tty flags
    tty_ups.c_iflag &= ~(BRKINT | ICRNL | IMAXBEL | IGNBRK | IXON);
    tty_ups.c_iflag |= IGNPAR;
    tty_ups.c_oflag &= ~(OPOST | ONLCR);
    tty_ups.c_lflag &= ~(IXON | ISIG | ICANON | IEXTEN | ECHO | ECHOE | ECHOK 
                         | ECHOCTL | ECHOKE);
    tty_ups.c_cflag &= ~(CSIZE | CRTSCTS);
    tty_ups.c_cflag |= (CS8 | PARENB | HUPCL);
    
    // we operate in blocking mode, so set VMIN and VTIME
    tty_ups.c_cc[VMIN] = 0;     // read with timeout
    tty_ups.c_cc[VTIME] = 20;    // timeout if chars are delayed by more than 2 seconds 

    // Save tty settings, also check for error
    if (tcsetattr(serial_port, TCSANOW, &tty_ups) != 0)
        printf("Error %i from tcsetattr: %s\n", errno, strerror(errno));

    return errno;
}

int serial_open(const char *serial_path)
{
    // open the serial port
    int serial_fd = open(serial_path, O_RDWR | O_NOCTTY);
    // Check for errors
    if (serial_fd < 0) {
        printf("ERROR: %i from open: %s\n", errno, strerror(errno));
        return errno;
    }

    if (flock(serial_fd, LOCK_EX | LOCK_NB) == -1) {
        printf("ERROR: Could not lock %s, exiting!\n", serial_path);
        fflush(stdout);
        return -1;
    }

    // flush the buffer
    tcflush(serial_fd, TCIOFLUSH);
    return serial_fd;
}

int serial_close(int serial_fd)
{
    return close(serial_fd);
}

int serial_write(uint8_t *p_msg, int n_msg, int serial_fd)
{   
    int i;
    int retval;
    retval = write(serial_fd, p_msg, n_msg);

    if (DEBUG) {
        printf("DEBUG: sending ");
        
        for (i =0; i < n_msg; i++)
            printf("%d ", p_msg[i]);
        printf("\n");
        fflush(stdout);
    }

    if (retval < 0) {
        printf("\tERROR in serial_read: %s\n", strerror(errno));
        return retval;
    }

    /*
     * // block until write is complete
     * return tcdrain(serial_fd);
     */

    // wait until write is complete
    usleep(SERIAL_WRITE_SLEEP_US);
    if (DEBUG) {
        printf("DEBUG: message sent\n");
        fflush(stdout);
    }
    return 0;
}

int serial_read(uint8_t *rx_buf, int n_msg, int serial_fd)
{
    int i;

    if (DEBUG) {
        printf("DEBUG: waiting for message receive...\n");
        fflush(stdout);
    }

    int retval = read(serial_fd, rx_buf, n_msg);
    if (retval < 0)
        printf("\tERROR: serial_read %s\n", strerror(errno));

    if (DEBUG) {
        printf("DEBUG: received "); 
        for (i =0; i < n_msg; i++)
            printf("%d ", rx_buf[i]);
        printf("\n");
        fflush(stdout);
    }

    if (retval != n_msg && retval != 0)
        printf("\tERROR: only %d bytes received\n", retval);

    if (retval == 0) {
        printf("ERROR: No data received from UPS, restarting application...\n");
        serial_close(serial_fd);
        exit(ERROR_UPS_UNREACHABLE);
    }

    return retval;
}