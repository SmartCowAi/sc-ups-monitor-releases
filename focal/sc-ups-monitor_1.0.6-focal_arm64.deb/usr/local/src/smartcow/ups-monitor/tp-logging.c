/*
 * Helper functions that record UPS data to files, intended to integrate with
 * TegraProducer on Jetson devices with an attached PB-4600J UPS
 *
 * Authors: Ryan Agius          <ryan@smartcow.ai>
 * 
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file COPYING in the main directory of this archive
 * for more details. 
 */

#include <stdio.h>
#include <string.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

#include "tp-logging.h"

#define OPEN_FLAGS O_CREAT | O_WRONLY | O_TRUNC
#define OPEN_MODE S_IWUSR | S_IRUSR | S_IRGRP | S_IROTH


int log_write_file(char *filepath, char *message)
{
    int open_retval = 0;
    int write_retval = 0;
    int close_retval = 0;

    int file_descriptor;

    open_retval = open(filepath, OPEN_FLAGS, OPEN_MODE);
    if (open_retval == -1)
        return -1;
    file_descriptor = open_retval;

    write_retval = write(file_descriptor, message, strlen(message));
    if (write_retval <= 0)
        return -1;

    close_retval = close(file_descriptor);
    if (close_retval == -1)
        return -1;

    return 0;
}

int log_write_status(char *status_filename, char *message)
{
    char status_filepath[128] = STATUS_DIR;
    strcat(status_filepath, status_filename);

    return log_write_file(status_filepath, message);
}

int log_write_config(char *config_filename, char *message)
{
    char config_filepath[128] = CONFIG_DIR;
    strcat(config_filepath, config_filename);

    return log_write_file(config_filepath, message);
}


int log_init_status(void)
{
    int write_status_retval;
    char init_message[] = "-1\n";

    // ups model
    write_status_retval = log_write_status(UPS_MODEL_FILE, init_message);
    if (write_status_retval < 0)
        return -1;

    // ups dc input voltage
    write_status_retval = log_write_status(UPS_DCIN_FILE, init_message);
    if (write_status_retval < 0)
        return -1;

    // ups power output
    write_status_retval = log_write_status(UPS_POUT_FILE, init_message);
    if (write_status_retval < 0)
        return -1;

    // ups remaining energy capacity
    write_status_retval = log_write_status(UPS_ENRG_FILE, init_message);
    if (write_status_retval < 0)
        return -1;

    // ups maximum energy capacity
    write_status_retval = log_write_status(UPS_ENRG_MAX_FILE, init_message);
    if (write_status_retval < 0)
        return -1;

    // ups remaining energy capacity percentage
    write_status_retval = log_write_status(UPS_ENRG_PERCENTAGE, init_message);
    if (write_status_retval < 0)
        return -1;

    // ups charging state
    write_status_retval = log_write_status(UPS_GHRG_FILE, init_message);
    if (write_status_retval < 0)
        return -1;

    // ups time to shutdown
    write_status_retval = log_write_status(UPS_TIME_TO_SHUTDOWN_FILE, init_message);
    if (write_status_retval < 0)
        return -1;

    // ups shutdown state
    write_status_retval = log_write_status(UPS_SHUTDOWN_FILE, init_message);
    if (write_status_retval < 0)
        return -1;

    return 0;
}

int log_init_config(void)
{
    int write_config_retval;
    char init_message[] = "-1\n";

    // ups_firmware_version
    write_config_retval = log_write_config(UPS_FW_VERSION_FILE, init_message);
    if (write_config_retval < 0)
        return -1;

    // ups_application_operating_mode
    write_config_retval = log_write_config(UPS_APP_OPMODE_FILE, init_message);
    if (write_config_retval < 0)
        return -1;

    // shutdown_trigger_dcin_limit_cycles
    write_config_retval = log_write_config(UPS_DCIN_MIN_CYCLES_FILE, init_message);
    if (write_config_retval < 0)
        return -1;

    // shutdown_trigger_dcin_limit
    write_config_retval = log_write_config(UPS_DCIN_MIN_FILE, init_message);
    if (write_config_retval < 0)
        return -1;

    // shutdown_trigger_energy_limit
    write_config_retval = log_write_config(UPS_SHDWN_ENRG_LIM_FILE, init_message);
    if (write_config_retval < 0)
        return -1;

    // suspend_power_threshold
    write_config_retval = log_write_config(UPS_SUSP_VAL_FILE, init_message);
    if (write_config_retval < 0)
        return -1;

    return 0;
}

int log_write_config_all(char *ups_fwver, char *opmode, char *dcmin_cycles, char *dcmin, char *enrg_min, char *susp_val)
{
    int write_config_retval;

    // ups_firmware_version
    write_config_retval = log_write_config(UPS_FW_VERSION_FILE, ups_fwver);
    if (write_config_retval < 0)
        return -1;

    // ups_application_operating_mode
    write_config_retval = log_write_config(UPS_APP_OPMODE_FILE, opmode);
    if (write_config_retval < 0)
        return -1;

    // shutdown_trigger_dcin_limit_cycles
    write_config_retval = log_write_config(UPS_DCIN_MIN_CYCLES_FILE, dcmin_cycles);
    if (write_config_retval < 0)
        return -1;

    // shutdown_trigger_dcin_limit
    write_config_retval = log_write_config(UPS_DCIN_MIN_FILE, dcmin);
    if (write_config_retval < 0)
        return -1;

    // shutdown_trigger_energy_limit
    write_config_retval = log_write_config(UPS_SHDWN_ENRG_LIM_FILE, enrg_min);
    if (write_config_retval < 0)
        return -1;

    // suspend_power_threshold
    write_config_retval = log_write_config(UPS_SUSP_VAL_FILE, susp_val);
    if (write_config_retval < 0)
        return -1;

    return 0;
}

