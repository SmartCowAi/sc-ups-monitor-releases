/*
 * Helper functions that record UPS data to files, intended to integrate with
 * TegraProducer on Jetson devices with an attached PB-4600J UPS
 *
 * Authors: Ryan Agius          <ryan@smartcow.ai>
 * 
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file COPYING in the main directory of this archive
 * for more details. 
 */

#ifndef SMC_TP_LOGGING_H_
#define SMC_TP_LOGGING_H_

#define CONFIG_DIR "/etc/smartcow/ups-monitor/config/"
#define STATUS_DIR "/etc/smartcow/ups-monitor/status/"

#define UPS_MODEL_FILE              "ups_model"

#define UPS_DCIN_FILE               "ups_dc_input_voltage"
#define UPS_POUT_FILE               "ups_power_output"
#define UPS_ENRG_FILE               "ups_energy_capacity"
#define UPS_ENRG_MAX_FILE           "ups_energy_capacity_max"
#define UPS_ENRG_PERCENTAGE         "ups_energy_capacity_percentage"
#define UPS_GHRG_FILE               "ups_charging_state"
#define UPS_TIME_TO_SHUTDOWN_FILE   "ups_time_to_shutdown"

#define UPS_SHUTDOWN_FILE           "ups_shutdown_state"

#define UPS_FW_VERSION_FILE         "ups_firmware_version"
#define UPS_APP_OPMODE_FILE         "ups_application_operating_mode"
#define UPS_DCIN_MIN_CYCLES_FILE    "shutdown_trigger_dcin_limit_cycles"
#define UPS_DCIN_MIN_FILE           "shutdown_trigger_dcin_limit"
#define UPS_SHDWN_ENRG_LIM_FILE     "shutdown_trigger_energy_limit"
#define UPS_SUSP_VAL_FILE           "ups_suspend_power_threshold"

/**
 * log_write_file() - populate file
 * @filepath: string containing file path
 * @message: char buffer containing string to write to file 
 * 
 * Returns 0 if successful, -1 if not
 */
int log_write_file(char *filepath, char *message);

/**
 * log_write_status() - populate status file
 * @status_filename: string containing name of status file to update
 * @message: char buffer containing string to write to file 
 * 
 * Returns 0 if successful, -ERR if not
 */
int log_write_status(char *status_filename, char *message);

/**
 * log_write_config() - populate config file
 * @config_filename: string containing name of config file to update
 * @message: char buffer containing string to write to file 
 * 
 * Returns 0 if successful, -ERR if not
 */
int log_write_config(char *config_filename, char *message);

/**
 * log_init_status() - populate status files on startup, indicating data not
 *                     available yet
 * 
 * Returns 0 if successful, -1 if not
 */
int log_init_status(void);

/**
 * log_init_config() - populate config files on startup, indicating data not
 *                     available yet
 * 
 * Returns 0 if successful, -1 if not
 */
int log_init_config(void);

/**
 * log_create_configs_all() - populate all config files
 * @ups_fwver: buffer containing the UPS firmware version
 * @opmode: buffer containing the set operating mode
 * @dcmin_cycles: buffer containing the mimimum bad dcin cycles to trigger a
 *                shutdown mode
 * @dcmin: buffer containing the minimum allowable DC input
 * @enrg_min: buffer containing the minimum remaining UPS energy level before
 *            a shutdown is trigerred
 * @susp_val: buffer containing the set SUSP value for the UPS
 * 
 * Returns 0 if successful, -1 if not
 */
int log_write_config_all(char *ups_fwver, char *opmode, char *dcmin_cycles, char *dcmin, char *enrg_min, char *susp_val);

#endif