/*
 * Initialises and monitors the status of a PB-4600J UPS connected via serial
 *
 * Authors: Ryan Agius   <ryan@smartcow.ai>
 *
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file COPYING in the main directory of this archive
 * for more details. 
 */

// always return 0 on success, negative int on fail

#include <stdio.h>
#include <string.h>

#include <sys/types.h>
#include <sys/stat.h>

#include <unistd.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>

#include <systemd/sd-daemon.h>
#include <signal.h>

#include "serial.h"
#include "tp-logging.h"
#include "sc-ups-monitor.h"

int ups = -1;

#define NUM_ARGS 3      // main always expects 3 args

void on_sigabrt(int sig_no)
{
    printf("ERROR: Received SIGABRT, exiting...\n");
    if (ups > 0)
        ups_release(ups);
    exit(-1);
}

int ups_open(const char *ups_serial_path)
{
    int ups, config_retval;

    ups = serial_open(ups_serial_path);
    if (ups < 0)
        return -1;

    config_retval = serial_configure(ups);
    if (config_retval < 0)
        return -1;

    return ups;   
}

int ups_release(int ups)
{
    return serial_close(ups);    
}

int get_checksum(uint8_t *data_packet_partial)
{
    uint8_t checksum = 0x00;
    int i;
    
    for (i = 0; i < UPS_RECVLEN-1; i++)
        checksum += data_packet_partial[i];

    return checksum;
}

int calc_checksum(uint8_t *data_packet_full)
{
    uint8_t checksum = get_checksum(data_packet_full);

    if (checksum != data_packet_full[UPS_RECVLEN-1])
        return -1;

    return 0;
}

int check_ups_model(int ups)
{
    uint8_t p_sendcmd[UPS_SENDLEN] = UPS_GETMODEL;
    uint8_t p_recvdata[UPS_RECVLEN]; 
    uint8_t p_upsmodel[UPS_RECVLEN-1] = UPS_MODEL;
    int i;
    int read_retval;
    
    // query model
    do {
        if (serial_write(p_sendcmd, UPS_SENDLEN, ups) < 0)
            return -1;
        read_retval = serial_read(p_recvdata, UPS_RECVLEN, ups);
        if (read_retval < 0)
            return -1;
    } while (read_retval != UPS_RECVLEN);  

    if (calc_checksum(p_recvdata) < 0)
        return -1;

    for (i = 0; i < UPS_RECVLEN-1; i++) {
        if (p_recvdata[i] != p_upsmodel[i])
            return 1;
    }

    return 0;
}

int check_ups_fw_version(int ups, char *p_ups_fw_version)
{
    uint8_t p_sendcmd[UPS_SENDLEN] = UPS_GETFWVER;
    uint8_t p_recvdata[UPS_FWREADTIME][UPS_RECVLEN]; 
    uint8_t p_upsminfw[UPS_RECVLEN] = UPS_MINFW;
    int i, j;
    int read_retval;

    // firmware version has no checksum, so read it UPS_FWREADTIME times and 
    // confirm that it is indentical
    
    // query firmware version
    for (i = 0; i < UPS_FWREADTIME; i++) {
        do {
            if (serial_write(p_sendcmd, UPS_SENDLEN, ups) < 0)
                return -1;
            read_retval = serial_read(p_recvdata[i], UPS_RECVLEN, ups);
            if (read_retval < 0)
                return -1;
        } while (read_retval != UPS_RECVLEN);  

        if (calc_checksum(p_recvdata[i]) < 0)
            return -1;
    }

    for (i = 0; i < UPS_FWREADTIME-1; i++) {
        for (j = 0; j < UPS_RECVLEN; j++) {
            if (p_recvdata[i][j] != p_recvdata[i+1][j]) {
                printf("ERROR: Firmware queries did not match!\n");
                fflush(stdout);
                return -1;
            }
        }
    }

    // store and print the FW version
    printf("STATUS: UPS firmware version is ");
    for (i = 0; i < UPS_RECVLEN; i++) {
        p_ups_fw_version[i] = p_recvdata[0][i];
        printf("%c", p_ups_fw_version[i]);
    }
    printf("\n");
    fflush(stdout);

    // check that FW version is equal to or greater than minimum version
    for (i = 0; i < UPS_RECVLEN; i++) {
        if (p_recvdata[0][i] < p_upsminfw[i])
            return 1;
    }

    return 0;
}

int get_ups_susp(int ups, uint8_t *susp_value)
{
    uint8_t p_sendcmd[UPS_SENDLEN] = UPS_GETSUSP;
    uint8_t p_recvdata[UPS_RECVLEN];

    int read_retval; 

    // query UPS SUSP value
    do {
        if (serial_write(p_sendcmd, UPS_SENDLEN, ups) < 0)
            return -1;
        read_retval = serial_read(p_recvdata, UPS_RECVLEN, ups);
        if (read_retval < 0)
            return -1;
    } while (read_retval != UPS_RECVLEN); 

    if (calc_checksum(p_recvdata) < 0)
        return -1;

    // and read the value from the data packet
    *susp_value = p_recvdata[0];
    
    return 0;
}

int set_ups_susp(int ups, uint8_t susp_value)
{
    // 0 -> no error, -1 -> error
    uint8_t p_sendcmd[UPS_SENDLEN] = UPS_SETSUSP;
    p_sendcmd[5] = susp_value;
    p_sendcmd[6] = get_checksum(p_sendcmd);

    if (serial_write(p_sendcmd, UPS_SENDLEN, ups) < 0)
        return -1;

    return 0;
}

int set_check_ups_susp(int ups, uint8_t susp_value)
{
    uint8_t set_susp_value = 255;
    uint8_t *p_set_susp_value = &set_susp_value;

    // UPS reboots if SUSP is set, so only set it if set != get

    // first get SUSP from the UPS
    if (get_ups_susp(ups, p_set_susp_value) < 0)
        return -1;

    if (*p_set_susp_value != susp_value) {
        // set susp
        if (set_ups_susp(ups, susp_value) < 0) {
            printf("ERROR: Failed to set SUSP, exiting...");
            fflush(stdout);
            return -1;
        }
        printf("WARNING: SUSP value set to %d, restarting...\n", susp_value);
        fflush(stdout);
        return 1;
    }

    printf("STATUS: SUSP remains set as %dW\n", susp_value);
    fflush(stdout);
    return 0;
}

int check_ups_charging(int ups, _Bool *p_is_charging)
{
    // 0 -> no error, -1 -> error
    uint8_t p_sendcmd[UPS_SENDLEN] = UPS_GETCHRG;
    uint8_t p_recvdata[UPS_RECVLEN];
    int read_retval;

    // query charge status
    do {
        if (serial_write(p_sendcmd, UPS_SENDLEN, ups) < 0)
            return -1;
        read_retval = serial_read(p_recvdata, UPS_RECVLEN, ups);
        if (read_retval < 0)
            return -1;
    } while (read_retval != UPS_RECVLEN); 

    if (calc_checksum(p_recvdata) < 0)
        return -1;

    *p_is_charging = p_recvdata[0];
    return 0;
}

int get_ups_enrg(int ups, float *p_enrg)
{
    uint8_t p_sendcmd[UPS_SENDLEN] = UPS_GETENRG;
    uint8_t p_recvdata[UPS_RECVLEN];
    uint32_t enrg_scaled;
    int read_retval; 

    // query UPS energy level
    do {
        if (serial_write(p_sendcmd, UPS_SENDLEN, ups) < 0)
            return -1;
        read_retval = serial_read(p_recvdata, UPS_RECVLEN, ups);
        if (read_retval < 0)
            return -1;
    } while (read_retval != UPS_RECVLEN); 

    if (calc_checksum(p_recvdata) < 0)
        return -1;

    // calculate energy level;
    enrg_scaled = p_recvdata[3] << 24 | 
                  p_recvdata[2] << 16 | 
                  p_recvdata[1] << 8 | 
                  p_recvdata[0];
    
    // and scale it to Ws
    *p_enrg = (float)enrg_scaled / UPS_ENRG_SF;
    
    return 0;
}

int get_ups_dcin(int ups, float *p_dcin)
{
    uint8_t p_sendcmd[UPS_SENDLEN] = UPS_GETDCIN;
    uint8_t p_recvdata[UPS_RECVLEN];
    uint32_t dcin_scaled; 
    int read_retval;

    // query DC input voltage
    do {
        if (serial_write(p_sendcmd, UPS_SENDLEN, ups) < 0)
            return -1;
        read_retval = serial_read(p_recvdata, UPS_RECVLEN, ups);
        if (read_retval < 0)
            return -1;
    } while (read_retval != UPS_RECVLEN); 

    if (calc_checksum(p_recvdata) < 0)
        return -1;

    // calculate dcin;
    dcin_scaled = p_recvdata[3] << 24 | 
                  p_recvdata[2] << 16 | 
                  p_recvdata[1] << 8 | 
                  p_recvdata[0];
    
    // and scale it
    *p_dcin = (float)dcin_scaled / UPS_DCIN_SF;
    
    return 0;
}

int get_ups_pout(int ups, int *p_pout)
{
    uint8_t p_sendcmd[UPS_SENDLEN] = UPS_GETPOUT;
    uint8_t p_recvdata[UPS_RECVLEN];
    uint32_t pout_scaled;
    int read_retval; 

    float pout;

    // query UPS power output
    do {
        if (serial_write(p_sendcmd, UPS_SENDLEN, ups) < 0)
            return -1;
        read_retval = serial_read(p_recvdata, UPS_RECVLEN, ups);
        if (read_retval < 0)
            return -1;
    } while (read_retval != UPS_RECVLEN); 

    if (calc_checksum(p_recvdata) < 0)
        return -1;

    // calculate output power
    pout_scaled = p_recvdata[3] << 24 | 
                  p_recvdata[2] << 16 | 
                  p_recvdata[1] << 8 | 
                  p_recvdata[0];
    
    // and scale it to mW
    pout = (float)pout_scaled * UPS_PWR_SF;
    *p_pout = (int)pout;
    
    return 0;
}

int get_ups_data(int ups, _Bool *p_is_charging, float *p_enrg,
                 float *p_dcin, int *p_pout)
{
    char log_ups_chrg[128];
    char log_ups_enrg[128];
    char log_ups_dcin[128];
    char log_ups_pout[128];

    int retval = 0;

    retval = check_ups_charging(ups, p_is_charging);
    if (retval < 0) {
        printf("WARNING: Could not check UPS charging state...\n");
        fflush(stdout);
        return -1;
    }

    retval = get_ups_enrg(ups, p_enrg);
    if (retval < 0) {
        printf("WARNING: Could not get UPS energy level...\n");
        fflush(stdout);
        return -1;
    }

    retval = get_ups_dcin(ups, p_dcin);
    if (retval < 0) {
        printf("WARNING: Could not get UPS input voltage measurement...\n");
        fflush(stdout);
        return -1;
    }

    retval = get_ups_pout(ups, p_pout);
    if (retval < 0) {
        printf("WARNING: Could not get UPS output power reading...\n");
        fflush(stdout);
        return -1;
    }

    if (*p_is_charging)
        sprintf(log_ups_chrg, "charging\n");
    else
        sprintf(log_ups_chrg, "discharging\n");
    sprintf(log_ups_enrg, "%.2f Ws\n", *p_enrg);
    sprintf(log_ups_dcin, "%.2f V\n", *p_dcin);
    sprintf(log_ups_pout, "%d mW\n", *p_pout);

    log_write_status(UPS_GHRG_FILE, log_ups_chrg);
    log_write_status(UPS_ENRG_FILE, log_ups_enrg);
    log_write_status(UPS_DCIN_FILE, log_ups_dcin);
    log_write_status(UPS_POUT_FILE, log_ups_pout);

    return 0;
}

int calc_ups_time_to_shutdown(int opmode, int *p_bad_dcin_count, 
                              _Bool *p_is_charging, float *p_enrg, int *p_pout)
{
    char log_ups_time_to_shutdown[128];
    int time_to_shutdown = -1;
    int remaining_enrg;

    // ups is charging, set remaining ontime to -1 and exit
    if ((*p_is_charging == true) && (*p_bad_dcin_count == 0)) {
        sprintf(log_ups_time_to_shutdown, "%d s\n", time_to_shutdown);
        return log_write_status(UPS_TIME_TO_SHUTDOWN_FILE, log_ups_time_to_shutdown);
    }

    if (opmode == 0) { // shuts down on bad dcin count
        time_to_shutdown = UPS_DCIN_MIN_CYCLES - *p_bad_dcin_count;
    } else if (opmode == 1) { // shuts down on remaining ups capacity
        remaining_enrg = (int)*p_enrg - UPS_SHDWN_ENRG_LIM;
        if (remaining_enrg <= 0)
            time_to_shutdown = 0;
        else
            // handle case when pout is 0
            if (*p_pout == 0.0) {
                sprintf(log_ups_time_to_shutdown, "Inf s\n");
                return log_write_status(UPS_TIME_TO_SHUTDOWN_FILE, log_ups_time_to_shutdown);
            } else {
                time_to_shutdown = (remaining_enrg*1000) / *p_pout;
            }
    } else {
        return -1;
    }
    
    sprintf(log_ups_time_to_shutdown, "%d s\n", time_to_shutdown);
    return log_write_status(UPS_TIME_TO_SHUTDOWN_FILE, log_ups_time_to_shutdown);
}

int calc_ups_enrg_percentage(float *p_enrg)
{   
    char log_ups_enrg_percentage[128];
    float scaled_ups_enrg_percentage = 10000;        // 100% * 100
    int ups_enrg_percentage;

    scaled_ups_enrg_percentage = *p_enrg * UPS_ENRG_PERCENTAGE_M + UPS_ENRG_PERCENTAGE_C;

    ups_enrg_percentage = (int)(scaled_ups_enrg_percentage / 100);

    sprintf(log_ups_enrg_percentage, "%d %%\n", ups_enrg_percentage);
    return log_write_status(UPS_ENRG_PERCENTAGE, log_ups_enrg_percentage);
}

int ups_shutdown(int ups)
{
    uint8_t p_sendcmd[UPS_SENDLEN] = UPS_SHUTDOWN;
    uint8_t p_recvdata[UPS_RECVLEN];
    uint8_t p_upsshdnok[UPS_RECVLEN-1] = UPS_SHUTDOWN_OK;
    int i;
    int read_retval;

    // send shutdown command to ups
    do {
        if (serial_write(p_sendcmd, UPS_SENDLEN, ups) < 0)
            return -1;
        read_retval = serial_read(p_recvdata, UPS_RECVLEN, ups);
        if (read_retval < 0)
            return -1;
    } while (read_retval != UPS_RECVLEN); 
    
    if (calc_checksum(p_recvdata) < 0)
        return 1;

    // check that shutdown response is as expected
    for (i = 0; i < UPS_RECVLEN-1; i++) {
        if (p_recvdata[i] != p_upsshdnok[i])
            return 1;
    }
    return 0;
}

void system_poweroff(int ups)
{
    char log_ups_shutdown[128];

    sprintf(log_ups_shutdown, "requested\n");
    log_write_status(UPS_SHUTDOWN_FILE, log_ups_shutdown);

    while(ups_shutdown(ups) == 1);
    sprintf(log_ups_shutdown, "triggered\n");
    log_write_status(UPS_SHUTDOWN_FILE, log_ups_shutdown);
    ups_release(ups);
    sleep(1);

    // reset config, status files as they are no longer valid
    log_init_config();
    log_init_status();

    while(system("shutdown -P now") == -1 ) {
        printf("ERROR: System could not shutdown, retrying...\n");
        fflush(stdout);
        sleep(1);
    }
}

int safe_restart(int ups, float *p_dcin, int *bad_dcin_count) 
{
    // check DCIN value, increment bad_count if < UPS_DCIN_MIN
    if (*p_dcin < UPS_DCIN_MIN) {
        *bad_dcin_count = *bad_dcin_count + 1;
        printf("WARNING: Bad DC IN = %.2f V, %d/10\n",
                        *p_dcin, *bad_dcin_count);
    } else {
        printf("STATUS: OK DCIN = %.2f V\n", *p_dcin);
        fflush(stdout);
        *bad_dcin_count = 0;
    }
    
    // poweroff system if bad_count > UPS_DCIN_MIN_CYCLES
    if (*bad_dcin_count > UPS_DCIN_MIN_CYCLES) {
        printf("ERROR: DC IN < UPS_DCIN_MIN for >%d seconds, shutting down...\n",
            UPS_DCIN_MIN_CYCLES);
        fflush(stdout);

        system_poweroff(ups);
        return 1;
    }

    return 0;
}

int quick_restart(int ups, _Bool *p_is_charging, float *p_enrg)
{

    if (*p_is_charging) 
        printf("STATUS: Charging");
    else 
        printf("WARNING: Discharging");
    printf(", energy = %.2f Ws\n", *p_enrg);
    fflush(stdout);

    if (*p_is_charging == false && *p_enrg < UPS_SHDWN_ENRG_LIM) {
        printf("ERROR: UPS discharging and energy below %d Ws shutdown limit, shutting down...\n",
            UPS_SHDWN_ENRG_LIM);
        fflush(stdout);

        system_poweroff(ups);
        return 1;
    }

    return 0;
}

int main(int argc, const char *argv[])
{
    int opmode = 0;
    int opmode_retval = 0;

    int retval;

    char p_ups_fw_version[UPS_RECVLEN+1] = UPS_BASEFW;

    int susp_value = -1;

    int ups_ttystat_retval;

    int get_ups_data_retval;

    _Bool is_charging = false;
    float enrg = 0.0;
    float dcin = 0.0;
    int pout = 0;
    int bad_dcin_count = 0;

    _Bool *p_is_charging = &is_charging;
    float *p_enrg = &enrg;
    float *p_dcin = &dcin;
    int *p_pout = &pout;
    int *p_bad_dcin_count = &bad_dcin_count;

    char log_ups_fwver[128];
    char log_opmode[128];
    char log_ups_dcin_min_cycles[128];
    char log_ups_dcin_min[128];
    char log_shdwn_enrg_lim[128];
    char log_susp_value[128];

    char log_ups_enrg_max[128];

    char log_ups_model[128];
    char log_ups_shutdown[128];

    // init status and config files
    log_init_status();
    log_init_config();

    // notify systemd watchdog
    sd_notify(0, "READY=1");

    // setup signal handling
    if (signal(SIGABRT, on_sigabrt) == SIG_ERR) {
        printf("ERROR: Can't catch SIGABRT\n");
        return -1;
    }

    // check argc
    if (argc != (NUM_ARGS + 1)) {
        printf("Wrong number of input arguments, nargs = %d, expected %d\n", argc-1, NUM_ARGS);
        fflush(stdout);
        return -1;
    }

    // check type of file in argv, must be char special
    struct stat ups_ttystat;
    ups_ttystat_retval = stat(argv[1], &ups_ttystat);
    if (ups_ttystat_retval < 0) {
        printf("ERROR: %s not present, exiting...\n", argv[1]);
        fflush(stdout);
        return -1;
    }
    if (S_ISCHR(ups_ttystat.st_mode) == 0) {
        printf("ERROR: %s not a character special device, exiting...\n", argv[1]);
        fflush(stdout);
        return -1;
    }

    // check operating mode;
    opmode = atoi(argv[2]);
    if (opmode != 0 && opmode != 1) {
        printf("ERROR: Bad opmode %d, expected 0 or 1, exiting...\n", opmode);
        fflush(stdout);
        return -1;
    }

    if (opmode == 0) {
        sprintf(log_opmode, "safe\n");
        printf("STATUS: Operating in safe restart mode...\n");
        fflush(stdout);
    } else {
        sprintf(log_opmode, "quick\n");
        printf("STATUS: Operating in quick restart mode...\n");
        fflush(stdout);
    }

    // open and configure ups serial
    ups = ups_open(argv[1]);
    if (ups < 0) {
        printf("ERROR: Unable to open UPS tty, retval %d, exiting...\n", ups);
        fflush(stdout);
        return -1;
    }

    // check model
    retval = check_ups_model(ups);
    if (retval < 0) {
        printf("ERROR: Cannot check UPS model, exiting...\n");
        fflush(stdout);
        ups_release(ups);
        return -1;
    } else if (retval == 1) {
        printf("ERROR: Wrong UPS model, only PB4600 is supported, exiting...\n");
        fflush(stdout);
        ups_release(ups);
        return -1;
    }
    sprintf(log_ups_model, "PB4600\n");
    log_write_status(UPS_MODEL_FILE, log_ups_model);

    // check FW, see if it's at least UPS_MINFW
    retval = check_ups_fw_version(ups, p_ups_fw_version);
    if (retval < 0) {
        printf("ERROR: Cannot check UPS FW version, exiting...\n");
        fflush(stdout);
        ups_release(ups);
        return -1;
    } else if (retval == 1) {
        printf("STATUS: UPS FW version below N23.06G, ignoring SUS setting...\n");
        fflush(stdout);
    } else {
        // UPS supports SUSP setting, so read and set it
        susp_value = atoi(argv[3]);
        if (susp_value == 0) {
            printf("ERROR: could not convert ARG to SUSP, exiting...\n");
            fflush(stdout);
            return -1;
        } else if (susp_value < 0) {
            printf("STATUS: ignoring SUSP...\n");
            fflush(stdout);
        } else if (susp_value > 255) {
            printf("ERROR: SUSP == %d is out of range, exiting...\n", susp_value);
            fflush(stdout);
            return -1;
        } else {
            // set and check susp value
            retval = set_check_ups_susp(ups, (uint8_t)susp_value);
            if (retval < 0) {
                printf("ERROR: SUSP value not set in UPS, exiting!\n");
                fflush(stdout);
                ups_release(ups);
                return -1;
            } else if (retval == 1) {
                ups_release(ups);
                return RETVAL_CHANGED_SUS_SETTING;
            }
        }
    }
    
    sprintf(log_ups_shutdown, "normal_operation\n");
    log_write_status(UPS_SHUTDOWN_FILE, log_ups_shutdown);

    sprintf(log_ups_fwver, "%s\n", p_ups_fw_version);
    sprintf(log_ups_dcin_min_cycles, "%d\n", UPS_DCIN_MIN_CYCLES);
    sprintf(log_ups_dcin_min, "%.1f V\n", UPS_DCIN_MIN);
    sprintf(log_shdwn_enrg_lim, "%d Ws\n", UPS_SHDWN_ENRG_LIM);
    sprintf(log_susp_value, "%d W\n", susp_value);

    log_write_config_all(log_ups_fwver, log_opmode, log_ups_dcin_min_cycles, 
                        log_ups_dcin_min, log_shdwn_enrg_lim, log_susp_value);

    sprintf(log_ups_enrg_max, "%d Ws\n", UPS_ENRG_MAX);
    log_write_status(UPS_ENRG_MAX_FILE, log_ups_enrg_max);

    while (1) {
        get_ups_data_retval = get_ups_data(ups, p_is_charging, 
                                           p_enrg, p_dcin, p_pout);
        if (get_ups_data_retval < 0) {
            printf("WARNING: Could not get ups data, retrying...\n");
            fflush(stdout);
            continue;
        }
        
        calc_ups_enrg_percentage(p_enrg);

        calc_ups_time_to_shutdown(opmode, p_bad_dcin_count,
                                  p_is_charging, p_enrg, p_pout);
                                  
        // refresh systemd watchdog
        sd_notify(0, "WATCHDOG=1");
        sleep(1);

        if (opmode == 0) {
            opmode_retval = safe_restart(ups, p_dcin, p_bad_dcin_count);
            // -1 -> error, 0 normal op, 1 -> initiated shutdown
            if (opmode_retval < 0)
                return -1;
            if (opmode_retval == 1)
                return 1;
        } else {
            opmode_retval = quick_restart(ups, p_is_charging, p_enrg);
            if (opmode_retval < 0)
                return -1;
            if (opmode_retval == 1)
                return 1;
        }
    }

    ups_release(ups);
    return 0;
}