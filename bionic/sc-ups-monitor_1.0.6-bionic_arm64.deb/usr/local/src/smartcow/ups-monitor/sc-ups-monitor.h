/*
 * Initialises and monitors the status of a PB-4600J UPS connected via serial
 *
 * Authors: Ryan Agius   <ryan@smartcow.ai>
 *
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file COPYING in the main directory of this archive
 * for more details. 
 */

/*
 * PB4600 PPROTOCOL DESCRIPTION
 *
 * The PB4600 UPS communicates over a serial RS232 protocol and behaves as a
 * slave device. When instructed by the master, it can return information about
 * the current operating conditions, as well as receive commands to shutdown
 * the UPS. While it is also possible to set some internal parameters of the
 * UPS through the RS232 bus, details of this are unknown.
 * 
 * DATA PACKET FORMAT
 * All data packets send to and received by the UPS are 7 bytes long, and have
 * the following format:
 * 
 * TRANSMITTED PACKETS
 *  ---------------------------------------------------------------------------
 * |      2 bytes      |            4 bytes           |         1 byte         | 
 * |---------------------------------------------------------------------------| 
 * |    0        1     |      2     3     4     5     |           6            | 
 * |---------------------------------------------------------------------------| 
 * |    instruction    |             action           |  lower byte checksum   | 
 * |      header       |                              |     of bytes 0 - 5     | 
 * ----------------------------------------------------------------------------
 * 
 *  RECEIVED PACKETS
 *  ---------------------------------------------------------------------------
 * |                     6 bytes                      |         1 byte         | 
 * |---------------------------------------------------------------------------| 
 * |     0       1       2      3      4      5       |           6            | 
 * |---------------------------------------------------------------------------| 
 * |                       data                       |  lower byte checksum   | 
 * |                                                  |     of bytes 0 - 5     | 
 * ----------------------------------------------------------------------------
 * 
 * Typical communication involves the master sending a properly formatted data 
 * packet with the correct instruction header and action, and receiving a
 * response from the UPS.
 * 
 * INSTRUCTION HEADERS
 * 
 * The known instruction headers that the master transmits are:
 *     - 0x23 0x3F -- master wishes to read UPS data
 *     - 0x21 0x21 -- master wishes to execute an instruction on the UPS
 * 
 * ACTION
 * 
 * These correspond to specific instructions that the master want the UPS to 
 * perform. There are 5 known commands that read the status of the UPS. and 1
 * known command to perform an action on the ups
 * 
 * ACTION - READ STATUS
 *     - 0x4d 0x4F 0x44 0x4C -- Read UPS model
 *     - 0x44 0x43 0x49 0x4E -- Read UPS DC input voltage (from wall source)
 *     - 0x50 0x4f 0x55 0x54 -- Read UPS power output to device
 *     - 0x45 0x4E 0x45 0x52 -- Read UPS stored energy
 *     - 0x43 0x48 0x52 0x47 -- Read UPS charging state
 * 
 * ACTION - TRIGGER ACTION
 *     - 0x53 0x48 0x4E 0x44 -- Trigger UPS shutdown
 * 
 * UPS Responses
 * The below section otulines the expected responses from the UPS upon receiving
 * the corresponing command from the master.
 * 
 * Read UPS Model
 * The UPS sends a data packet having the form 
 * ['P', 'B', '4', '6', '0', '0', <checksum>].
 * 
 * READ UPS DC Input Voltage
 * The UPS sends a data packet having the form 
 * [X, X, D0, D1, D2, D3, <checksum>]. X are unknown bits (need to check).
 * The scaled DC input voltage is received in little endian format, and
 * must be propely shifted to obtain the correct value.
 * An empirically obtained scaling factor is then used to calculate the 
 * corresponding measurement in Volts.
 * DC input in volts = 0xD3 0xD2 0xD1 0xD0 * scaling-factor
 * 
 * READ UPS Power Output
 * The UPS sends a data packet having the form 
 * [X, X, D0, D1, D2, D3, <checksum>]. X are unknown bits (need to check).
 * The scaled power output is received in little endian format, and
 * must be propely shifted to obtain the correct value.
 * An empirically obtained scaling factor is then used to calculate the 
 * corresponding measurement in Watts.
 * Power output in Watts = 0xD3 0xD2 0xD1 0xD0 * scaling-factor
 * 
 * READ UPS Total Energy
 * The UPS sends a data packet having the form 
 * [X, X, D0, D1, D2, D3, <checksum>]. X are unknown bits (need to check).
 * The scaled energy storage reading is received in little endian format, and
 * must be propely shifted to obtain the correct value.
 * An empirically obtained scaling factor is then used to calculate the 
 * corresponding measurement in Joules.
 * Energy stored in Joules  = 0xD3 0xD2 0xD1 0xD0 * scaling-factor
 * 
 * READ UPS Charging State
 * The UPS sends a data packet having the form
 * [0x01, 0x00, 0x00 0x00, 0x00, 0x00, <checksum>] if the UPS is actively
 * charging, and a packet having the form 
 * [0x00, 0x00, 0x00 0x00, 0x00, 0x00, <checksum>] if the UPS is not actively
 * charging.
 * Actively charging implies that the UPS is connected to a DC power source and
 * is using power to charge its internal capacitors. The UPS is considered to be
 * actively charging even if its capacity reaches 100%, as in normal operation.
 * If the UPS is shutdown, it will not start charging again until the UPS 
 * discharges to around 25% capacity, at which point it will reset and start
 * charging.
 * 
 * TRIGGER UPS Shutdown
 * The UPS sens a data packet having the form
 * ['@', '@', 'S', 'H', 'D', 'N', <checksum>] if the shutdown was trigerred
 * correctly.
 * Upon receiving the command, the UPS begins the shutdown process, at which
 * point it will not start charging again from the DC supply until the UPS
 * discharges to around 25% capacity, at which point it resets and starts to
 * charge up back to full capacity.
 * The DC output is maintained during the discharge process, disabled during
 * the charging process, and re-enabled once the UPS charges fully.
 * 
 */

#include <stdint.h>
#include <stdbool.h>

#ifndef SMC_UPSMON_H_
#define SMC_UPSMON_H_

#define RETVAL_CHANGED_SUS_SETTING      12

#define UPS_SENDLEN     7       // messages are always 7 bytes
#define UPS_RECVLEN     7       // messages are always 7 bytes

#define UPS_READCMD     '#', '\?'

#define UPS_GETPARAMS   {'>', 'P', 'A', 'R', 'A', '?', 0xA1}        // get all UPS Params

#define UPS_GETMODEL    {UPS_READCMD, 'M', 'O', 'D', 'L', 0x8E}     // get UPS model number
#define UPS_GETFWVER    {UPS_READCMD, 'V', 'E', 'R', 'S', 0xA2}     // get UPS firmware version
#define UPS_GETDCIN     {UPS_READCMD, 'D', 'C', 'I', 'N', 0x80}     // get DC input voltage
#define UPS_GETPOUT     {UPS_READCMD, 'P', 'O', 'U', 'T', 0xAA}     // get power output
#define UPS_GETENRG     {UPS_READCMD, 'E', 'N', 'E', 'R', 0x8C}     // get UPS total energy
#define UPS_GETCHRG     {UPS_READCMD, 'C', 'H', 'R', 'G', 0x86}     // is UPS charging?

#define UPS_GETSUSP     {UPS_READCMD, 'S', 'U', 'S', 'P', 0xAD}     // get SUSP setting
#define UPS_SETSUSP     {'>', 'S', 'U', 'S', 'P'}  

#define UPS_SHUTDOWN    {'!', '!', 'S', 'H', 'D', 'N', 0x6F}    // shutdown UPS
#define UPS_SHUTDOWN_OK {'@', '@', 'S', 'H', 'D', 'N'}

#define UPS_MODEL       {'P', 'B', '4', '6', '0', '0'}
#define UPS_MINFW       {'N', '2', '3', '.', '0', '6', 'G'}
#define UPS_BASEFW      {'.', '.', '.', '.', '.', '.', '.', '\0'}

#define UPS_FWREADTIME          3           // number of times to re-read UPS firmware

#define UPS_SUSP_DEFAULT        3           // default SUSP value is 3W

#define UPS_DCIN_MIN_CYCLES     10          // number of cycles before shutdown
#define UPS_DCIN_MIN            10.0        // DCIN must be at least 10V
#define UPS_DCIN_SF             28.18       // DCIN reading scaling factor

#define UPS_ENRG_MAX            4780        // Maximum UPS energy capacity
#define UPS_ENRG_MIN            1150        // Minimum UPS energy capacity
#define UPS_ENRG_PERCENTAGE_M   2.755       // UPS energy percentage gradient
#define UPS_ENRG_PERCENTAGE_C   -3168       // UPS energy percentage intercept

#define UPS_SHDWN_ENRG_LIM      1750        // Energy reading in Ws that triggers shutdown
#define UPS_ENRG_SF             154.3781    // Energy reading scaling factor

// Pout(mW) = X * UPS_PWR_SF + UPS_PWR_OFFSET
// OFFSET negligible, so ignored
#define UPS_PWR_SF          20.06       // Power reading scaling factor
// #define UPS_PWR_OFFSET      23.66       // Power reading offset

/**
 * ups_open() - open, init and config a ups device over serial
 * @serial_path: absolute path of serial device
 * 
 * Returns the serial port file descriptor if successful, -ERR if not
 */
int ups_open(const char *serial_path);

/**
 * ups_release() - deinit and close UPS device over serial
 * @ups: UPS serial port file descriptor
 * 
 * Returns 0 if successful, -ERR if not
 */
int ups_release(int ups);

/**
 * get_checksum() - return the checksum of a partial data packet
 * @data_packet_partial: 6-bit partial data packet on which to calculate the 
 *                       checksum
 * 
 * Returns the checksum as a uint8_t value
 */
int get_checksum(uint8_t *data_packet_partial);

/**
 * calc_checksum() - determine if a checksum is valid
 * @data_packet_full: 7-bit data packet on which to calculate and verify 
 *                    checksum value
 * 
 * 0 if the checksum is valid, -1 if not
 */
int calc_checksum(uint8_t *data_packet_full);

/**
 * check_ups_model() - asserts that the UPS is a PB4600 model
 * @ups: UPS serial port file descriptor
 * 
 * Returns 0 if the UPS is the correct model, 1 if not, -ERR in case of error
 */
int check_ups_model(int ups);

/**
 * check_ups_fw_version() - asserts that the UPS firmware version is at least 
 *                          UPS_MINFW 
 * @ups: UPS serial port file descriptor
 * @p_ups_fw_version: string containing received FW version from UPS
 * 
 * Returns 0 if the UPS is the correct model, 1 if not, -ERR in case of error
 */
int check_ups_fw_version(int ups, char *p_ups_fw_version);

/**
 * get_ups_susp() - get ups system status power input threshold
 * @ups: UPS serial port file descriptor
 * 
 * Returns 0 on success -ERR in case of error
 * *p_sus_power set to >= 0 power threshold, -1 on error
 */
int get_ups_susp(int ups, uint8_t *susp_value);

/**
 * set_ups_susp() - set ups system status determined by power input, and set 
 * power input threshold
 * @ups: UPS serial port file descriptor
 * @susp_value: input power threshold for UPS to consider system as on
 * 
 * Returns 0 on success -ERR in case of error
 */
int set_ups_susp(int ups, uint8_t susp_value);

/**
 * set_check_ups_susp() - set ups system status determined by power input, set 
 *                        power input threshold and verify that is is set 
 *                        correctly. Reboots system if
 * @ups: UPS serial port file descriptor
 * @susp_value: input power threshold for UPS to consider system as on
 * 
 * Returns 0 on no SUSP change, 1 on SUSP change, -ERR in case of error
 */
int set_check_ups_susp(int ups, uint8_t susp_value);

/**
 * check_ups_charging() - checks if ups is charging
 * @ups: UPS serial port file descriptor
 * @is_charging: pointer to _Bool is_charging variable
 * 
 * Returns 0 on success -1 in case of error
 * *p_is_charging set to true if UPS is charging, false otherwise
 */
int check_ups_charging(int ups, _Bool *p_is_charging);

/**
 * get_ups_enrg() - gets UPS' current energy level, in Ws
 * @ups: UPS serial port file descriptor
 * @p_enrg: pointer to float energy variable
 * 
 * Returns 0 on success -1 in case of error
 * *p_energ set to UPS energy level in Ws
 */
int get_ups_enrg(int ups, float *p_enrg);

/**
 * get_ups_dcin() - gets UPS' current input voltage, in V
 * @ups: UPS serial port file descriptor
 * @p_dcin: pointer to float DC input variable
 * 
 * Returns 0 on success -1 in case of error
 * *p_dcin set to UPS input voltage in V
 */
int get_ups_dcin(int ups, float *p_dcin);

/**
 * get_ups_pout() - gets UPS' current output power, in mW
 * @ups: UPS serial port file descriptor
 * @p_pout: pointer to int power output variable
 * 
 * Returns 0 on success -1 in case of error
 * *p_pwr set to UPS output power in mW
 */
int get_ups_pout(int ups, int *p_pout);

/**
 * get_ups_data() - uses the get_ups_* functions to obtain all available status
 * information from the UPS, and populates the appropriate variables.
 * Also updates files in /etc/...
 * @ups: UPS serial port file descriptor
 * @is_charging: pointer to _Bool is_charging variable
 * @p_enrg: pointer to float energy variable
 * @p_dcin: pointer to float DC input variable
 * @p_pout: pointer to integer power output variable
 * 
 * Returns 0 on success -1 in case of error
 * *p_is_charging set to true if UPS is charging, false otherwise
 * *p_energ set to UPS energy level in Ws
 * *p_dcin set to UPS input voltage in V
 * *p_pout set to UPS output power in mW
 */
int get_ups_data(int ups, _Bool *p_is_charging, float *p_enrg,
                 float *p_dcin, int *p_pout);

/**
 * calc_ups_time_to_shutdown() - estimates the time remaining until the ups is
 * sent a shutdown command. Writes this estimate to a file.
 * @opmode: ups monitor operating mode
 * @p_bad_dcin_count: pointer to int bad dcin count
 * @is_charging: pointer to _Bool is_charging variable
 * @p_enrg: pointer to float energy variable
 * @p_pout: pointer to integer power output variable
 * 
 * Returns 0 if successful, -1 in case of error
 */
int calc_ups_time_to_shutdown(int opmode, int *p_bad_dcin_count, 
                              _Bool *p_is_charging, float *p_enrg, int *p_pout);

/**
 * calc_ups_enrg_percentage() - estimates the remainig ups capacity as a
 * percentage. Writes this estimate to a file.
 * @p_enrg: pointer to float energy variable
 * 
 * Returns 0 if successful, -1 in case of error
 */
int calc_ups_enrg_percentage(float *p_enrg);

/**
 * ups_shutdown() - send shutdown command to UPS 
 * @ups: UPS serial port file descriptor
 * 
 * Returns 0 if successful, -ERR in case of error
 */
int ups_shutdown(int ups);

/**
 * system_poweroff() - shutdown the UPS and the system
 * @ups: UPS serial port file descriptor
 */
void system_poweroff(int ups);

/**
 * safe_restart() - safe restart loop where UPS and device are shutdown after 
 *                  UPS_DCIN_MIN_CYCLES seconds of UPS DCIN < UPS_DCIN_MIN. UPS
 *                  must be fully discharged efore device reboots, so downtime
 *                  is longer.
 * @ups: UPS serial port file descriptor
 * @p_dcin: pointer to float DC input variable
 * @p_bad_dcin_count: pointer to int bad dcin count
 * 
 * Returns 0 if successful, 1 if device is shutdown, -ERR in case of error
 */
int safe_restart(int ups, float *p_dcin, int *p_bad_dcin_count);

/**
 * quick_restart() - quick restart loop where UPS and device are shutdown when
 *                   UPS is discharging and has a current energy level below 
 *                   UPS_SHDWN_ENRG_LIM. UPS fully discharges quicker, so
 *                   downtime is shorter.
 * @ups: UPS serial port file descriptor
 * @is_charging: pointer to _Bool is_charging variable
 * @p_enrg: pointer to float energy variable
 * 
 * Returns 0 if successful, 1 if device is shutdown, -ERR in case of error
 */
int quick_restart(int ups, _Bool *p_is_charging, float *p_enrg);

#endif
